function validateEmail() {
  var emailInput = document.getElementById('email');
  var errorMessage = document.getElementById('error-message');
  var email = emailInput.value;

  // Verifica se o email tem pelo menos um caractere após o @
  if (email.includes('@') && email.split('@')[1].length > 0) {
      errorMessage.textContent = ''; // Limpa a mensagem de erro
  } else {
      errorMessage.textContent = 'Erro: Email inválido';
  }
}

function outraQuantidade(botao) {
  var valor = prompt("Digite o valor desejado:");
  var mensagem = document.getElementById('mensagem');
  mensagem.textContent = "";

  var botoes = document.querySelectorAll('.bt');
  botoes.forEach(function(b) {
      b.classList.remove('selecionado');
  });

  botao.classList.add('selecionado');


  if (valor !== null && !isNaN(valor)) {
      atualizarBotao(parseFloat(valor));
  } else {
      alert("Por favor, insira um número válido.");
  }
}

function atualizarBotao(valor) {
  var botao = document.getElementById('bt4');
  var mensagem = document.getElementById('mensagem');
  botao.textContent = valor + "€";
  n_ref = valor/1.5;
  if(botao.classList.contains('texto')){
    mensagem.textContent = "O seu donativo permitirá alimentar uma pessoa durante " + Math.floor(n_ref) + " dias.";
    
  }
  else if(valor < 90){
    mensagem.textContent = "O seu donativo permitirá fornecer aproximadamente " + Math.floor(n_ref) + " refeições.";
  }
  else{
    n_ref = valor/3;
    mensagem.textContent = "O seu donativo permitirá fornecer aproximadamente " + Math.floor(n_ref) + " refeições.";
  }

}

function selecionarValor(botao, valor) {

  var botoes = document.querySelectorAll('.bt');
    botoes.forEach(function(b) {
        b.classList.remove('selecionado');
    });

  botao.classList.add('selecionado');
  
  // Atualiza a mensagem conforme o valor selecionado
  var mensagem = document.getElementById('mensagem');
  var bt1 = document.getElementById('bt1');

  if(bt1.classList.contains("texto")){
     if (valor === 10) {
          mensagem.textContent = "O seu donativo permitirá alimentar uma pessoa durante 3 dias.";
          nome.value="20€";
      } else if (valor === 15) {
          mensagem.textContent = "O seu donativo permitirá alimentar uma pessoa durante 5 dias.";
          nome.value="";
      } else if (valor === 25) {
          mensagem.textContent = "O seu donativo permitirá alimentar uma pessoa durante 8 dias.";
          nome.value="";
      }
    
  }
  else{
    if (valor === 10) {
      mensagem.textContent = "O seu donativo permitirá fornecer aproximadamente 13 refeições.";
      nome.value="20€";
  } else if (valor === 15) {
      mensagem.textContent = "O seu donativo permitirá fornecer aproximadamente 26 refeições.";
      nome.value="40€";
  } else if (valor === 25) {
      mensagem.textContent = "O seu donativo permitirá fornecer aproximadamente 53 refeições.";
      nome.value="80€";
  }
  }
 
}


function mostrarCampos() {
  var tipoDoacao = document.getElementById("tipoDoacao").value;
  var camposParticular = document.getElementById("camposParticular");
  var camposEmpresa = document.getElementById("camposEmpresa");

  if (tipoDoacao === "particular") {
      camposParticular.classList.remove("hidden");
      camposEmpresa.classList.add("hidden");
  } else if (tipoDoacao === "empresa") {
      camposParticular.classList.add("hidden");
      camposEmpresa.classList.remove("hidden");
  }
}

function metodoPagamento() {
  var paymentMethod = document.getElementById("pagamento").value;
  
  // Ocultar todos os campos
  document.getElementById("creditCardFields").classList.add("hidden");
  document.getElementById("paypalFields").classList.add("hidden");
  document.getElementById("multibancoFields").classList.add("hidden");
  document.getElementById("mbwayFields").classList.add("hidden");
  document.getElementById("mensal-credito").classList.add("hidden");
  document.getElementById("mensal-debito").classList.add("hidden");

  // Mostrar os campos relevantes com base na opção de pagamento escolhida
  if (paymentMethod === "creditCard") {
      document.getElementById("creditCardFields").classList.remove("hidden");
  } else if (paymentMethod === "paypal") {
      document.getElementById("paypalFields").classList.remove("hidden");
  } else if (paymentMethod === "multibanco") {
      document.getElementById("multibancoFields").classList.remove("hidden");
  } else if (paymentMethod === "mbway") {
      document.getElementById("mbwayFields").classList.remove("hidden");
  }

 
  
}
function pagamentomensal(){
  var mensal = document.getElementById("pagamento-mensal").value;
  document.getElementById("mensal-credito").classList.add("hidden");
  document.getElementById("mensal-debito").classList.add("hidden");
  document.getElementById("creditCardFields").classList.add("hidden");
  document.getElementById("paypalFields").classList.add("hidden");
  document.getElementById("multibancoFields").classList.add("hidden");
  document.getElementById("mbwayFields").classList.add("hidden");
  
  if (mensal === "credito"){
    document.getElementById("mensal-credito").classList.remove("hidden");
  } else if (mensal === "debito") {
      document.getElementById("mensal-debito").classList.remove("hidden");
  }
}
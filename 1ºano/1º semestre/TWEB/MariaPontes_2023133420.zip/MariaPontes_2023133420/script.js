document.addEventListener('DOMContentLoaded', () => {
    const menuToggle = document.querySelector('.menu-toggle');
    const menu = document.querySelector('.menu');

    menuToggle.addEventListener('click', () => {
        menu.classList.toggle('active');
    });
});
function toggleMenu() {
    const menu = document.querySelector('.menu');
    menu.classList.toggle('active');
}

// Form inicial
function switchTab(tabId) {
    const tabs = document.querySelectorAll('.tab');
    const contents = document.querySelectorAll('.content1');

    tabs.forEach(tab => {
        tab.classList.remove('active');
    });

    contents.forEach(content => {
        content.classList.remove('active');
    });

    document.querySelector(`.tab[onclick="switchTab('${tabId}')"]`).classList.add('active');
    document.getElementById(tabId).classList.add('active');
}

// Flight Status Simulation
const form = document.getElementById('flight-status');
const resultsDiv = document.getElementById('results');

form.addEventListener('submit', (e) => {
    e.preventDefault();

    // Capturar os dados do formulário
    const date = new Date(document.getElementById('flight-date').value);
    const city = document.getElementById('departure-city').value;
    const type = document.getElementById('flight-type').value;

    // Validar que todos os campos foram preenchidos
    if (!date || !city || !type) {
        alert('Por favor, preencha todos os campos!');
        return;
    }

    // Determinar status do voo e horários
    const isEvenDay = date.getDate() % 2 === 0;
    const isEvenMonth = (date.getMonth() + 1) % 2 === 0;

    const status1 = type === 'one-way'
        ? isEvenDay ? 'No horário' : 'Atrasado'
        : isEvenMonth ? 'No horário' : 'Chegou';

    const flightTimes = city.toLowerCase() === 'lisboa'
        ? ['10:05', '18:05']
        : ['12:10', '20:10'];

    // Gerar a saída dinâmica
    resultsDiv.innerHTML = `
        <p><strong>Voo 1:</strong></p>
        <p>Número do Voo: TP1</p>
        <p>Dia do Voo: ${date.toDateString()}</p>
        <p>Hora do Voo: ${flightTimes[0]}</p>
        <p>Destino ou Chegada: ${type === 'one-way' ? 'Destino' : 'Chegada'} - ${city}</p>
        <p>Status do Voo: ${status1}</p>
        <br>
        <p><strong>Voo 2:</strong></p>
        <p>Número do Voo: TP2</p>
        <p>Dia do Voo: ${date.toDateString()}</p>
        <p>Hora do Voo: ${flightTimes[1]}</p>
        <p>Destino ou Chegada: ${type === 'one-way' ? 'Destino' : 'Chegada'} - ${city}</p>
        <p>Status do Voo: ${status1}</p>
    `;
});

document.getElementById('signupButton').addEventListener('click', function() {
    alert('Thank you for signing up!');
});
